import { validatorMessage } from "@/constants/validatorMessage";
import { kMaxLength } from "buffer";
import * as Yup from "yup";

export const OrderEditValidator = () =>{
    const {requiredField, numericField, minValue, length} = validatorMessage;
    return Yup.object().shape({
        date: Yup.string().required(requiredField).length(10, length),
        document: Yup.string().required(requiredField).length(11, length),
        paymentType: Yup.string().required(requiredField),
        itemQuantity: Yup.number().typeError(numericField).required(requiredField).min(1, minValue),
        totalValue: Yup.number().required(requiredField).typeError(numericField).min(0.01, minValue)
        // description: Yup.string().required(validatorMessage.requiredField).min(3, minLenght).max(100, maxLenght),
        // brand: Yup.string().required().max(80, maxLenght),
        // value: Yup.number().required().min(0.01, minValue).typeError(numericField),
        // weight: Yup.number().min(0.01, minValue).typeError(numericField),
        // flavor: Yup.string(),
    })
}