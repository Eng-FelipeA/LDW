export const validatorMessage = {
    requiredField: "Campo obrigatório",
    numericField: "Campo é numérico",
    minLenght: "Campo de ter pelo menos ${min} caracteres",
    maxLenght: "Campo deve ter no máximo ${max} caracteres",
    minValue: "Valor mínimo ${min}",
    maxValue: "Valor máximo ${max}",
    length:"Campo deve ter ${leght} caracteres",
}