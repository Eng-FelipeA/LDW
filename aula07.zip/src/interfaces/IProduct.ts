export interface IProduct {
    id?: number; //? significa q não é obrigatório
    description: string;
    brand: string;
    value: number;
    weight: number;
    flavor: string;
}