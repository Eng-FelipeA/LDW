"use client";
import React, { useEffect, useState } from "react";

import EditTemplate from "@/components/templates/products/EditTemplate";
import axios from "axios";
import { IProduct } from "@/interfaces/IProduct";
import { env } from "@/config/env";
import { withDataFetching } from "@/components/HOCS/withDataFetching";

interface ProductEditProps {
  params?: { slug: string };
  data: any;
}

const ProductEdit: React.FC<ProductEditProps> = ({ params, data }) => {
  const [product, setProduct] = useState<IProduct>();



  useEffect(() => {
    if(!data) return;
      const {
        id,
        descricao: description,
        marca: brand,
        valor: value,
        peso_gramas: weight,
        sabor: flavor,
      } = data.produto;

      setProduct({
        id,
        brand,
        description,
        flavor,
        value,
        weight,
      });
    }, [data]);

  return <EditTemplate product={product} />;
};

export default withDataFetching(`${env.apiBaseUrl}/produto`)(ProductEdit);
