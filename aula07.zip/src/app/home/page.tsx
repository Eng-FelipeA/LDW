import Layout from "@/components/UI/organisms/Layout";
import { Box } from "@mui/material";

const Home = () => {
  return <Layout name="layout"> 
    <Box> Bem Vindo! </Box> 
    </Layout>;
};

export default Home;
