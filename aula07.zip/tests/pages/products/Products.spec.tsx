import { render, screen } from "@testing-library/react";
import Products from "@/app/products/page";
import mockRouter from "next-router-mock";
import { setupServer } from "msw/node";
import { http } from "msw";
import { env } from "@/config/env";

jest.mock("next/navigation", () => require("next-router-mock"));

const server = setupServer(
    http.get(`${env.apiBaseUrl}/produto`, () => {
        return Response.json({
            produto:
                {id: 1,
                descricao: "Bolacha",
                marca: "Trakinas",
                valor: 1.99,
                peso_gramas: 100,
                sabor: "morango",
                },
        });
    })
);

describe("Products List Page", () =>{
    beforeAll(() => {
        mockRouter.setCurrentUrl("/products");
        server.listen();
    });
    afterAll(() => {
        server.close();
    });
    it("Should render product list", async () => {
        render(<Products/>);

        const productName = await screen.findByRole('cell', {
            name: /trakinas/i
          });

          console.log(productName);

        screen.logTestingPlaygroundURL();
    });
});