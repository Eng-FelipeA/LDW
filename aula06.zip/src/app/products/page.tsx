"use client";

import CustomTable from "@/components/UI/organisms/CustomTable";
import Layout from "@/components/UI/organisms/Layout";
import { env } from "@/config/env";
import { Description } from "@mui/icons-material";
import { Box } from "@mui/material";
import axios from "axios";
import { useEffect, useState } from "react";

const Products = () => {

  const [rows, setRows] = useState([]);

  useEffect(() => {
    const fetchProducts = async () =>{
      console.log(`${env.apiBaseUrl}/produto`)
    const response = await axios.get(`${env.apiBaseUrl}/produto`);

    const products = response.data.produtos.map((product: any) => ({
      id: product.id,
      description: product.descricao,
      brand: product.marca,
      value: product.valor,
      weight: product.peso_gramas,
      flavor: product.sabor
    }));

    setRows(products);
  
  }

    fetchProducts();

  }, []);
  const headCells = [
    {
      id: "description",
      numeric: false,
      disablePadding: false,
      label: "descricao",
    },
    {
      id: "brand",
      numeric: false,
      disablePadding: false,
      label: "marca",
    },
    {
      id: "value",
      numeric: true,
      disablePadding: false,
      label: "valor",
    },
    {
      id: "weight",
      numeric: true,
      disablePadding: false,
      label: "peso",
    },
    {
      id: "flavor",
      numeric: false,
      disablePadding: false,
      label: "sabor",
    },
  ];

  return (
    <Layout>
      <Box> Lista de Produtos </Box>
      <CustomTable rows={rows} headCells={headCells} editPath="/products/edit"/>
    </Layout>
  );
}

export default Products;  
