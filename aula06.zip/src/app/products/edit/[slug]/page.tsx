"use client";
import React from "react";

import EditTemplate from "@/components/templates/products/EditTemplates";

 
interface ProductEditProps {
  params: { slug: string };
}
 
const ProductEdit: React.FC<ProductEditProps> = ({ params }) => {

  return <EditTemplate/>

};
 
export default ProductEdit;