"use client";
import React from "react";

import EditTemplate from "@/components/templates/products/EditTemplates";

 
interface ProductEditProps {
  params: { slug: string };
}
 
const ProductEdit: React.FC<ProductEditProps> = ({ params }) => {

  const productId = Number(params.slug)
  
  return <EditTemplate productId = {productId}/>

};
 
export default ProductEdit;