import { validatorMessage } from "@/constants/validatorMessage";
import { kMaxLength } from "buffer";
import * as Yup from "yup";

export const ProductEditValidator = () =>{
    const {requiredField, numericField, minValue, maxValue, minLenght, maxLenght} = validatorMessage;
    return Yup.object().shape({
        description: Yup.string().required(validatorMessage.requiredField).min(3, minLenght).max(100, maxLenght),
        brand: Yup.string().required().max(80, maxLenght),
        value: Yup.number().required().min(0.01, minValue).typeError(numericField),
        weight: Yup.number().min(0.01, minValue).typeError(numericField),
        flavor: Yup.string(),
    })
}