export interface IOrder {
    date: string;
    document: string;
    paymentType: string;
    itemQuantity: number;
    totalValue: string;
}